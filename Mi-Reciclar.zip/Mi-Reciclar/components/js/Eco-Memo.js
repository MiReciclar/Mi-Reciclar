const board = document.querySelector(".board")
const card = document.querySelector(".board ")
console.log(card)

const lista_ruta_imagenes = [
    "../img/img-perfil/papelera-de-reciclaje.png",
    "../img/img-perfil/lapiz.png",
    "../img/img-perfil/papelera-de-reciclaje.png",
    "../img/img-perfil/perfil.png",
    "../img/img-perfil/personita.png"
]

function crearCard (src, index){
    const card = document.createElement("div")
    card.classList.add(`card-${index}`, "card")
    card.innerHTML= `<img src=${src}>`


    board.appendChild(card)
}
for (let index = 0; index < 9; index++) {
    //console.log(Math.floor(Math.random() * 4 + 1))
    console.log(Math.floor(Math.random() * 3) + 1)
    
    crearCard(lista_ruta_imagenes[Math.floor(Math.random() * 3) + 1],index)
}

card.addEventListener("click", e =>{
    console.log(e.target)

    //e.target.classList.toggle("flip-vertical-right")
})
